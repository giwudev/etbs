@extends('site.welcome')

@section('content')
99999
@endsection