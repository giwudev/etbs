@extends('site.welcome')

@section('content')

@include('site.entete')


@endsection