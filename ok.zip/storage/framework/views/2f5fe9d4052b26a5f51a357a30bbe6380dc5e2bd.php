<title><?php echo e(Config('app.name')); ?> | Faire un appel</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php echo trans('data.stylePdf'); ?> 
<div class="footer"><i><?php echo trans('data.signaturePdf'); ?> <span class="pagenum"></span> </i></div>

<?php if(count($list) != 0): ?>
	<div><h3 style="text-align:center;">Faire un appel<br>
		<?php if(!empty($_GET['query'])): ?>
			Recherche : <?php echo e($_GET['query']); ?><br>
		<?php endif; ?>
	</h3></div>

	<table class="table" style="font-size:15px; width:100%;">
		<tr>
			<th class="th" ><?php echo trans('data.id_appel'); ?></th>
			<th class="th" ><?php echo trans('data.emploi_id'); ?></th>
			<th class="th" ><?php echo trans('data.eleve_id'); ?></th>
			<th class="th" ><?php echo trans('data.init_id'); ?></th>
			<th class="th" ><?php echo trans('data.etat_appel'); ?></th>
		</tr>
		<tbody><?php echo e($i = 1); ?>

			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr style="background-color : <?php if ($i % 2 == 0) {echo '#ffffff';$i++;}else{echo trans("data.styleLignePdf");$i++;} ?>;">
					<td class="td"><?php echo e($listgiwu->id_appel); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->emploitemp) ? $listgiwu->emploitemp->heure_debut : trans('data.not_found')); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->eleve) ? $listgiwu->eleve->nom_el : trans('data.not_found')); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found')); ?></td>
					<td class="td"><?php echo e($listgiwu->etat_appel); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php else: ?>
	<div><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\etbs\resources\views/appeler/pdf.blade.php ENDPATH**/ ?>