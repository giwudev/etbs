
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<div class="modal-content">
	<div class="modal-header card-header">
		<h5 class="modal-title" id="varyingcontentModalLabel">Motif de rejet du dossier : <?php echo e($item->agent->nom_ag.' '.$item->agent->prenom_ag); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	</div>
	<div class="modal-body">
		<strong><div class="msgAction"></div></strong>
		<form id="formAction" class="needs-validation" novalidate>
			<?php echo Form::hidden('id_dossier',$item->id_dossier,["class"=>"form-control"]); ?>

			<?php echo Form::hidden('typeMenu',$typeMenu,["id"=>"typeMenu"]); ?>

			<?php echo csrf_field(); ?>
			<div>
				<div class="mb-3">
					<label for="motif_txt" class="form-label"><?php echo trans('data.motif'); ?> </label>
					<?php echo Form::textarea('motif',null,["id"=>"motif","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Motif",'rows'=>"3" ]); ?>

					<span class="text-danger" id="motifError"></span>
				</div>
			</div>
			<p class="text-muted mb-4"> Le rejet sera envoyé à <?php echo e($RecupRole); ?>. </p>
			<div class="modal-footer">
				<button type="button" class="btn btn-light" data-bs-dismiss="modal">Femer</button>
				<button id="valider" type="button"  class="btn btn-danger btn-load" onclick="addAction();"> 
					<span class="d-flex align-items-center"><span class="flex-grow-1 me-2">Rejeter</span><span class="flex-shrink-0" role="status"></span></span>
				</button>
			</div>
		</form>
	</div>
</div>

<script type="text/javascript"> $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}}); </script>

<script type="text/javascript">
	function addAction(){
		$('#valider').attr("disabled",!0);
		$('#valider .flex-shrink-0').addClass("spinner-border");
		$("div.msgAction").html('').hide(200);
		$('#motifError').addClass('d-none');

		var typeM = $("#typeMenu").val();
		let url_ = '<?php echo e(url("dossier:id/rejetData")); ?>';
		url_ = url_.replace(':id',typeM);
		$.ajax({
			type: 'POST',url: url_, data: $('#formAction').serialize(),
			success: function(data) {
				$('#valider').attr("disabled",!1);
				$('#valider .flex-shrink-0').removeClass("spinner-border");
				if(data.response!=1){
					$.each(data.response, function(Key, value){var ErrorID = '#'+Key+'Error';$(ErrorID).removeClass('d-none');$(ErrorID).text(value);})
				}else{
					$("div.msgAction").html('<div class="alert alert-success alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Infos </strong> Dossier rejeté avec succès </div>').show(200);
					window.location.reload();
				}
			},
			error: function(data) {}
		});
	}

</script>
<?php /**PATH C:\wamp\www\formation\resources\views/dossier/rejeter.blade.php ENDPATH**/ ?>