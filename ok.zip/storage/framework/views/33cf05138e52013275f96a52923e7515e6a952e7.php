<meta name='csrf-token' content='<?php echo e(csrf_token()); ?>'>

<div class="modal-content">
	<div class="modal-header card-header"><h5 class="modal-title" id="varyingcontentModalLabel">Soumettre le dossier</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
	<div class="modal-body"><strong><div class="msgAction"></div></strong>
		<form id="formAdDossier" class="needs-validation"  method="post" novalidate enctype='multipart/form-data'>
			<?php echo csrf_field(); ?>
			<div class="row">
				<span class="text-danger" id="GlobalError"></span> 
				<?php echo Form::hidden('id_pf',$id_pf,['id'=>'id_pf']); ?>

				<?php echo Form::hidden('type_dos',$type_dos,['id'=>'type_dos']); ?>

				<?php if(count($listPiece) != 0): ?>

					<?php $__currentLoopData = $listPiece; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($list->id_asspj != '22' && $list->id_asspj != '23' ): ?>
							<div class="col-md-6">
								<div class="mb-3">
									<label for="fichier_plan" class="form-label"><?php echo e($list->libelle_asspj); ?> 
										<?php if($list->requis_file == "Oui"): ?> <strong style='color: red;'> *</strong> <?php endif; ?>
									</label>
									<input class="form-control" type="file" id="fichier<?php echo e($list->id_asspj); ?>" name="fichier<?php echo e($list->id_asspj); ?>">
									<span class="text-danger" id="fichier<?php echo e($list->id_asspj); ?>Error"></span>
								</div>
							</div>
						<?php else: ?>
							<?php if(session('InfosAgent')->is_bourse == 1 && $list->id_asspj == '23'): ?>
								<div class="col-md-6">
									<div class="mb-3">
										<label for="fichier_plan" class="form-label"><?php echo e($list->libelle_asspj); ?> 
											<?php if($list->requis_file == "Oui"): ?> <strong style='color: red;'> *</strong> <?php endif; ?>
										</label>
										<input class="form-control" type="file" id="fichier<?php echo e($list->id_asspj); ?>" name="fichier<?php echo e($list->id_asspj); ?>">
										<span class="text-danger" id="fichier<?php echo e($list->id_asspj); ?>Error"></span>
									</div>
								</div>
							<?php elseif(session('InfosAgent')->is_bourse == 0 && $list->id_asspj == '22'): ?>
								<div class="col-md-6">
									<div class="mb-3">
										<label for="fichier_plan" class="form-label"><?php echo e($list->libelle_asspj); ?> 
											<?php if($list->requis_file == "Oui"): ?> <strong style='color: red;'> *</strong> <?php endif; ?>
										</label>
										<input class="form-control" type="file" id="fichier<?php echo e($list->id_asspj); ?>" name="fichier<?php echo e($list->id_asspj); ?>">
										<span class="text-danger" id="fichier<?php echo e($list->id_asspj); ?>Error"></span>
									</div>
								</div>
							<?php endif; ?>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					Aucun 
				<?php endif; ?>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline-dark waves-effect waves-light" data-bs-dismiss="modal">Femer</button>
				<button id="valider" type="button"  class="btn btn-primary btn-label right btn-load" onclick="addAction();">
					<span class="d-flex align-items-center"><span class="flex-grow-1 me-2">Soumettre</span><span class="flex-shrink-0" role="status"></span></span>
					<i class="ri-add-line label-icon align-middle fs-16 ms-2"></i>
				</button>
			</div>
		</form>
	</div>
</div>
	
<script type="text/javascript"> $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}}); </script>

<script type="text/javascript">
	function addAction(){

		const element = $('#formAdDossier')[0];
		const dataA = new FormData(element);
		const formA = Array.from(dataA.entries());

		$('#valider').attr("disabled",!0);
		$('#valider .flex-shrink-0').addClass("spinner-border");
		$("div.msgAction").html('').hide(200);
		for (const [name, value] of formA) {
			// console.log({ name, value, id });
			$('#'+name+'Error').addClass('d-none');
		}
		$('#GlobalError').addClass('d-none');
		
		var form = $('#formAdDossier')[0];
		var data = new FormData(form);
		$.ajax({
			type: 'POST',url: '<?php echo e(url("/dossierAgent/")); ?>',
			enctype:'multipart/form-data',data: data,processData: false,contentType: false,
			success: function(data) {
				$('#valider').attr("disabled",!1);
				$('#valider .flex-shrink-0').removeClass("spinner-border");
				if(data.response==1){
					$("div.msgAction").html('<div class="alert alert-success alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Infos </strong> Dossier soumis avec succès </div>').show(200);
					window.location.reload();
				}else if(data.response==0){
					$("div.msgAction").html('<div class="alert alert-danger alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Echec de l\'enregistrement</strong> '+data.message+'</div>').show(200);
				}else{
					$.each(data.response, function(Key, value){
						var ErrorID = '#'+Key+'Error';
						$(ErrorID).removeClass('d-none');
						$(ErrorID).text(value);
						if(Key == 'GlobalError'){
							$('#GlobalError').removeClass('d-none');
							$('#GlobalError').text(value);
						}
					})
				}
			},error: function(data) {
				console.log(data)
			}
		});
	}
</script>

<?php /**PATH C:\wamp\www\formation\resources\views/site/agent/addossier.blade.php ENDPATH**/ ?>