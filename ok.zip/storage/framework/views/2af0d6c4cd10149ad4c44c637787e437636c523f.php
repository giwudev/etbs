<meta name='csrf-token' content='<?php echo e(csrf_token()); ?>'>

<div class="modal-content">
	<div class="modal-header card-header"><h5 class="modal-title" id="varyingcontentModalLabel">Parcours traitement du dossier</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
	<div class="modal-body"><strong><div class="msgAction"></div></strong>
		<form id="formAdDossier" class="needs-validation"  method="post" novalidate enctype='multipart/form-data'>
			<?php echo csrf_field(); ?>
			<?php if(count($listParcouDossier) != 0): ?>
                <div class="card-body ">
                    <div class="table-responsive">
                        <table class="table table-borderless text-center table-nowrap align-middle mb-0">
                            <thead>
                                <tr class="table-active">
                                    <th scope="col" style="width: 50px;">N°</th>
                                    <th class="text-start">Détails</th>
                                    <th class="text-start">Par</th>
                                    <th class="text-start">à</th>
                                    <th scope="col">Etat</th>
                                </tr>
                            </thead>
                            <?php $i=0; ?>
                            <tbody id="products-list">
                                <?php $__currentLoopData = $listParcouDossier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $i++; ?>
                                    <tr>
                                        <th scope="row"><?php echo e($i); ?></th>
                                        <?php if($line->etat_trans == 'r'): ?>
                                            <td class="text-start"><?php echo e($line->detail_trans.' ('.$line->motif.')'); ?></td>
                                        <?php else: ?>
                                            <td class="text-start"><?php echo e($line->detail_trans); ?></td>
                                        <?php endif; ?>
                                        <td class="text-start"><?php echo e(isset($line->fromRole) ? $line->fromRole->libelle_role : 'Vous'); ?></td>
                                        <td class="text-start"><?php echo e(isset($line->toRole) ? $line->toRole->libelle_role : 'Vous'); ?></td>
                                        <td>
                                            <?php if($line->etat_trans == 'v'): ?>
                                                <span class="badge bg-success"><?php echo e(trans('entite.etape_dossier')[$line->etat_trans]); ?></span> 
                                            <?php elseif($line->etat_trans == 'r'): ?>
                                                <span class="badge bg-danger"><?php echo e(trans('entite.etape_dossier')[$line->etat_trans]); ?></span> 
                                            <?php else: ?>
                                                <?php echo e(trans('entite.etape_dossier')[$line->etat_trans]); ?>

                                            <?php endif; ?>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!--end table-->
                    </div>
                </div>
            <?php else: ?> 
                <div Class="alert alert-info m-4"><strong>Info! </strong>Dossier toujours en attente de traitement</div>
            <?php endif; ?>
			
		</form>
	</div>
</div>
	
<script type="text/javascript"> $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}}); </script>
<?php /**PATH C:\wamp\www\formation\resources\views/site/agent/Parcoursdossier.blade.php ENDPATH**/ ?>