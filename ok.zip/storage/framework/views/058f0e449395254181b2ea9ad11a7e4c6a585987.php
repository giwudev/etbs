<title><?php echo e(Config('app.name')); ?> | Liste des ecoles</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php echo trans('data.stylePdf'); ?> 
<div class="footer"><i><?php echo trans('data.signaturePdf'); ?> <span class="pagenum"></span> </i></div>

<?php if(count($list) != 0): ?>
	<div><h3 style="text-align:center;">Liste des ecoles<br>
		<?php if(!empty($_GET['query'])): ?>
			Recherche : <?php echo e($_GET['query']); ?><br>
		<?php endif; ?>
	</h3></div>

	<table class="table" style="font-size:15px; width:100%;">
		<tr>
			<th class="th" ><?php echo trans('data.nom_eco'); ?></th>
			<th class="th" ><?php echo trans('data.sigle_eco'); ?></th>
			<th class="th" ><?php echo trans('data.adres_eco'); ?></th>
			<th class="th" ><?php echo trans('data.ville_eco'); ?></th>
			<th class="th" ><?php echo trans('data.CodePos_eco'); ?></th>
			<th class="th" ><?php echo trans('data.pays_eco'); ?></th>
			<th class="th" ><?php echo trans('data.tel_eco'); ?></th>
			<th class="th" ><?php echo trans('data.email_eco'); ?></th>
			<th class="th" ><?php echo trans('data.directeur_eco'); ?></th>
			<th class="th" ><?php echo trans('data.niveau_educ_eco'); ?></th>
			<th class="th" ><?php echo trans('data.init_id'); ?></th>
		</tr>
		<tbody><?php echo e($i = 1); ?>

			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr style="background-color : <?php if ($i % 2 == 0) {echo '#ffffff';$i++;}else{echo trans("data.styleLignePdf");$i++;} ?>;">
					<td class="td"><?php echo e($listgiwu->nom_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->sigle_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->adres_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->ville_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->CodePos_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->pays_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->tel_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->email_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->directeur_eco); ?></td>
					<td class="td"><?php echo e($listgiwu->niveau_educ_eco); ?></td>
					<td class="td"><?php echo e(isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found')); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php else: ?>
	<div><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\etbs\resources\views/ecole/pdf.blade.php ENDPATH**/ ?>