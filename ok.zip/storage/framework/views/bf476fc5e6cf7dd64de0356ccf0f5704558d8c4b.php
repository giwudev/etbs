
    <!-- auth-bg-cover -->
    <!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">


<!-- Mirrored from themesbrand.com/velzon/html/default/landing.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 13:33:24 GMT -->
<head>

    <meta charset="utf-8" />
    <title>Site</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!--Swiper slider css-->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
</head>

<body data-bs-spy="scroll" data-bs-target="#navbar-example">

    <!-- Begin page -->
    <div class="layout-wrapper landing">

        
        <?php echo $__env->yieldContent('content'); ?>
        <!-- end hero section -->
          <!-- start plan -->
        <section class="section bg-light" id="plans">
            <div class="bg-overlay bg-overlay-pattern"></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="text-center mb-5">
                            <h3 class="mb-3 fw-semibold">Liste des pièces à fournies </h3>
                            <div class="flex-shrink-0  me-1">
                                <i class="ri-checkbox-circle-fill text-success fs-15 align-middle"></i> Fichier obligatoire
                                <i class="ri-close-circle-fill text-danger fs-15 align-middle"></i> Fichier facultatif
                            </div>
                        </div>
                    </div>
                    <!-- end col -->
                </div>
                <!-- end row -->
                <?php if(count($typePiece) != 0): ?>
                    <div class="row gy-4">
                        <?php $__currentLoopData = $typePiece; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($type != '-1'): ?>
                                <div class="col-lg-4">
                                    <div class="card plan-box mb-0">
                                        <div class="card-body p-4 m-2">
                                            <div class="d-flex align-items-center">
                                                <div class="flex-grow-1">
                                                    <h5 class="mb-1 fw-semibold"><?php echo e($key); ?></h5>
                                                    <p class="text-muted mb-0"><?php echo e($key); ?></p>
                                                </div>
                                                <div class="avatar-sm">
                                                    <div class="avatar-title bg-light rounded-circle text-primary">
                                                        <i class="ri-book-mark-line fs-20"></i>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="py-4 text-center">
                                                <!-- <h1 class="month"><sup><small>$</small></sup><span class="ff-secondary fw-bold">19</span> <span class="fs-13 text-muted">/Month</span></h1> -->
                                            </div>

                                            <div>
                                                <ul class="list-unstyled text-muted vstack gap-3 ff-secondary">
                                                <?php $listpiece = \App\Models\Associerpiece::ListPiece($type); ?>
                                                    <?php $__currentLoopData = $listpiece; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($line->requis_file == 'Oui'): ?>
                                                            <li>
                                                                <div class="d-flex">
                                                                    <div class="flex-shrink-0 text-success me-1">
                                                                        <i class="ri-checkbox-circle-fill fs-15 align-middle"></i>
                                                                    </div>
                                                                    <div class="flex-grow-1"> <?php echo e($line->libelle_asspj); ?></div>
                                                                </div>
                                                            </li>
                                                        <?php else: ?>
                                                            <li>
                                                                <div class="d-flex">
                                                                    <div class="flex-shrink-0 text-danger me-1">
                                                                        <i class="ri-close-circle-fill fs-15 align-middle"></i>
                                                                    </div>
                                                                    <div class="flex-grow-1"><?php echo e($line->libelle_asspj); ?></div>
                                                                </div>
                                                            </li>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                <?php endif; ?>
                <!--end row-->
            </div>
            <!-- end container -->
        </section>
        <!-- end plan -->
        <?php if(count($list_PF) != 0): ?>
            <!-- start services -->
            <section class="section" id="services">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <div class="text-center mb-5">
                                <h1 class="mb-3 ff-secondary fw-semibold lh-base">Procès-verbaux</h1>
                                <p class="text-muted">Délibération des procès</p>
                            </div>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- end row -->

                    <div class="row g-3">
                        <?php $__currentLoopData = $list_PF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4">
                                <div class="d-flex p-3">
                                    <div class="flex-shrink-0 me-3">
                                        <div class="avatar-sm icon-effect">
                                            <div class="avatar-title bg-transparent text-success rounded-circle">
                                                <i class="ri-file-2-line fs-36"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h5 class="fs-14 text-truncate"><a href="#" class="text-dark"><?php echo e(trans('data.reference')); ?> : <?php echo e($line->ref_pf); ?></a></h5>
                                        <p class="text-muted text-truncate mb-0">
                                            <span class="fw-semibold text-dark"><?php echo e(trans('data.date_sign_pf')); ?> : </span> <?php echo e(date('d/m/Y',strtotime($line->date_sign_pf))); ?> <br>
                                            <span class="fw-semibold text-dark">Du </span> <?php echo e(date('d/m/Y',strtotime($line->date_debu_pf))); ?>

                                            <span class="fw-semibold text-dark"> au </span> <?php echo e(date('d/m/Y',strtotime($line->date_fin_pf))); ?>

                                        </p>
                                        <p class="text-muted my-3 ff-secondary"><span class="fw-semibold text-dark"> <?php echo e(trans('data.entite_id')); ?> : </span><?php echo e(isset($line->entite) ? $line->entite->libelle_entite : '--'); ?></p>
                                        <div>
                                            <a class="badge badge-soft-danger fs-15" href='<?php echo e("assets/docs/".$line->fichier_proces); ?>' target="_blank" role="button">Télécharger le procès-verbal</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <!-- end col -->
                    </div>
                    <!-- end row -->
                </div>
                <!-- end container -->
            </section>
        <?php endif; ?>
        <!-- end services -->
        <!-- start client section -->
        <?php if(count($list_Entite) != 0): ?>
        <div class="mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">

                        <div class="text-center mt-5">
                            <h5 class="fs-20"> Administrations concercées</h5>
                            <!-- Swiper -->
                            <div class="swiper trusted-client-slider mt-sm-5 mt-4 mb-sm-5 mb-4" dir="ltr">
                                <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $list_Entite; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="swiper-slide">
                                            <div class="client-images">
                                            <h1 class="mb-3 ff-secondary fw-semibold lh-base" title ="<?php echo e($list->libelle_entite); ?>"><?php echo e($list->sigle_entite); ?></h1>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end client section -->
        <?php endif; ?>



        <!-- Start footer -->
        <footer class="custom-footer bg-dark py-5 position-relative">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 mt-4">
                        <div>
                            <div>
                                <img src="assets/images/logo-mtfpas.png" alt="logo light" height="45">
                            </div>
                            <div class="mt-4 fs-13">
                                <p>Plan de formation</p>
                                <p class="ff-secondary">La direction générale de l'administration et de la fonction publique (DGAFP) 
                                        élabore un schéma directeur triennal de la politique de formation professionnelle tout au long de la vie des agents de l'Etat. 
                                            Ce schéma définit les priorités de formation dans les domaines communs à l'ensemble des ministères.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7 ms-lg-auto">
                        <div class="row">
                            <div class="col-sm-6 mt-4">
                                <h5 class="text-white mb-0">Liens rapides </h5>
                                <div class="text-muted mt-3">
                                    <ul class="list-unstyled ff-secondary footer-list">
                                        <li><a href="#">Site Web</a></li>
                                        <li><a href="#">Gallery</a></li>
                                    </ul>
                                </div>
                            </div>
                           
                            <div class="col-sm-6 mt-4">
                                <h5 class="text-white mb-0">Support</h5>
                                <div class="text-muted mt-3">
                                    <ul class="list-unstyled ff-secondary footer-list">
                                        <li><a href="#">FAQ</a></li>
                                        <li><a href="#">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row text-center text-sm-start align-items-center mt-5">
                    <div class="col-sm-6">

                        <div>
                            <p class="copy-rights mb-0">
                                <script> document.write(new Date().getFullYear()) </script> © PF
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-end mt-3 mt-sm-0">
                            <ul class="list-inline mb-0 footer-social-link">
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-facebook-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-github-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-linkedin-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-google-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-dribbble-line"></i>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end footer -->


        <!--start back-to-top-->
        <button onclick="topFunction()" class="btn btn-danger btn-icon landing-back-top" id="back-to-top">
            <i class="ri-arrow-up-line"></i>
        </button>
        <!--end back-to-top-->

    </div>
    <!-- end layout wrapper -->

    <?php echo $__env->yieldContent('JS_content'); ?>
    <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!--Swiper slider js-->
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- landing init -->
    <script src="assets/js/pages/landing.init.js"></script>
    
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.allselect').select2();
        });
    </script>
</body>


<!-- Mirrored from themesbrand.com/velzon/html/default/landing.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 13:33:55 GMT -->
</html>
<?php /**PATH C:\wamp\www\formation\resources\views/site/welcome.blade.php ENDPATH**/ ?>