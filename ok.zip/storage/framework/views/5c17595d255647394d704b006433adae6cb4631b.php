<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
    <table class="table table-striped table-bordered table-nowrap">
        <thead>
            <tr>
                <th scope="col"><?php echo trans('data.heure_debut') . ' - ' . trans('data.heure_fin'); ?></th>
                <!-- <th scope="col"><?php echo trans('data.heure_fin'); ?></th> -->
                <th scope="col" class="text-center"><?php echo trans('data.jour_semaine'); ?></th>
                <th scope="col" class="text-center"><?php echo trans('data.discipline_id'); ?></th>
                <th scope="col" class="text-center"><?php echo trans('data.promotion_id'); ?></th>
                <th scope="col" class="text-center"><?php echo trans('data.annee_id'); ?></th>
                <th scope="col" class="text-center"><?php echo trans('data.prof_id'); ?></th>
                <!-- <th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th> -->
                <?php if(in_array('update_emploitemp', session('InfosAction')) || in_array('delete_emploitemp', session('InfosAction'))): ?>
                    <th class="text-center"> Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo substr($listgiwu->heure_debut, 0, 5) . ' - ' . substr($listgiwu->heure_fin, 0, 5); ?></td>
                    <!-- <td><?php echo $listgiwu->heure_fin; ?></td> -->
                    <td style='text-align:right'>
                        <?php echo e(trans('entite.semaine')[$listgiwu->jour_semaine]); ?></td>
                    <td><?php echo isset($listgiwu->discipline) ? $listgiwu->discipline->code_disci : trans('data.not_found'); ?></td>
                    <td><?php echo isset($listgiwu->promotion) ? $listgiwu->promotion->libelle_pro : trans('data.not_found'); ?></td>
                    <td><?php echo isset($listgiwu->anneesco)
                        ? $listgiwu->anneesco->annee_debut . ' ' . $listgiwu->anneesco->annee_fin
                        : trans('data.not_found'); ?></td>
                    <td><?php echo isset($listgiwu->users_g)
                        ? $listgiwu->users_g->name . ' ' . $listgiwu->users_g->prenom
                        : trans('data.not_found'); ?></td>
                    <!-- <td><?php echo isset($listgiwu->users_g)
                        ? $listgiwu->users_g->name . ' ' . $listgiwu->users_g->prenom
                        : trans('data.not_found'); ?></td> -->
                    <?php if(in_array('update_emploitemp', session('InfosAction')) || in_array('delete_emploitemp', session('InfosAction'))): ?>
                        <td class="text-center">
                            <?php if(in_array('update_emploitemp', session('InfosAction'))): ?>
                                <a href="<?php echo e(route('emploitemp.edit', $listgiwu->id_empl)); ?>" title='Modifier'
                                    class="btn btn-success btn-sm  waves-effect waves-light"><i
                                        class="ri-edit-2-line"></i></a>
                            <?php endif; ?>
                            <?php if(in_array('delete_emploitemp', session('InfosAction'))): ?>
                                <button type="button" title='Supprimer' data-id="<?php echo e($listgiwu->id_empl); ?>"
                                    class="btn btn-danger btn-sm  waves-effect waves-light btn-delete"
                                    data-bs-toggle="modal"><i class="ri-delete-bin-6-line"></i></button>
                            <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo $list->appends(['query' => isset($_GET['query']) ? $_GET['query'] : ''])->links(); ?>

<?php else: ?>
    <div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\etbs\resources\views/emploitemp/index-search.blade.php ENDPATH**/ ?>