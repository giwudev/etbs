<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
    <table class="table table-striped table-bordered table-nowrap">
        <thead>
            <tr>
                <th scope="col"><?php echo trans('data.libelle_trimSem'); ?></th>
                <th scope="col"><?php echo trans('data.statut_trimSem'); ?></th>
                <th scope="col" class="text-center"><?php echo 'Date Début'; ?></th>
                <th scope="col" class="text-center"><?php echo 'Date Fin'; ?></th>
                <th scope="col" class="text-center"><?php echo trans('data.annee_id'); ?></th>
                <th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th>
                <?php if(in_array('update_trimsem', session('InfosAction')) || in_array('delete_trimsem', session('InfosAction'))): ?>
                    <th class="text-center"> Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo $listgiwu->libelle_trimSem; ?></td>
                    <td>
                        <?php if($listgiwu->statut_trimSem == 'a'): ?>
                            <span
                                class="badge bg-success"><?php echo e(trans('entite.statutanne')[$listgiwu->statut_trimSem]); ?></span>
                        <?php else: ?>
                            <span
                                class="badge bg-danger"><?php echo e(trans('entite.statutanne')[$listgiwu->statut_trimSem]); ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo $listgiwu->date_debut ? date('d/m/Y',strtotime($listgiwu->date_debut)) : ' '; ?> </td>
                    <td><?php echo $listgiwu->date_fin ? date('d/m/Y',strtotime($listgiwu->date_fin)) : ' '; ?> </td>

                    <td><?php echo isset($listgiwu->anneesco)
                        ? $listgiwu->anneesco->annee_debut . ' - ' . $listgiwu->anneesco->annee_fin
                        : trans('data.not_found'); ?></td>
                    <td><?php echo isset($listgiwu->users_g)
                        ? $listgiwu->users_g->name . ' ' . $listgiwu->users_g->prenom
                        : trans('data.not_found'); ?></td>
                    <?php if(in_array('update_trimsem', session('InfosAction')) || in_array('delete_trimsem', session('InfosAction'))): ?>
                        <td class="text-center">
                            <?php if(in_array('update_trimsem', session('InfosAction'))): ?>
                                <a href="<?php echo e(route('trimsem.edit', $listgiwu->id_trimSem)); ?>" title='Modifier'
                                    class="btn btn-success btn-sm  waves-effect waves-light"><i
                                        class="ri-edit-2-line"></i></a>
                            <?php endif; ?>
                            <?php if(in_array('delete_trimsem', session('InfosAction'))): ?>
                                <button type="button" title='Supprimer' data-id="<?php echo e($listgiwu->id_trimSem); ?>"
                                    class="btn btn-danger btn-sm  waves-effect waves-light btn-delete"
                                    data-bs-toggle="modal"><i class="ri-delete-bin-6-line"></i></button>
                            <?php endif; ?>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php echo $list->appends(['query' => isset($_GET['query']) ? $_GET['query'] : ''])->links(); ?>

<?php else: ?>
    <div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\etbs\resources\views/trimsem/index-search.blade.php ENDPATH**/ ?>