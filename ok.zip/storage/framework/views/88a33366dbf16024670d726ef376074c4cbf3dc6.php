<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>

	<a href='#' class='btn btn-primary btn-label right waves-light' id='btn-consulter'><i class='ri-eye-fill label-icon align-middle fs-16 ms-2'></i> Consulter le dossier</a>	

	<?php if(in_array('avis_motive_dossier'.$typeMenu,session('InfosAction'))): ?>
		<button type='button' class='btn btn-secondary btn-label right waves-light' id='btn-avis-motive'><i class='ri-file-line label-icon align-middle fs-16 ms-2'></i> Avis motivé</button>
	<?php endif; ?>
	<?php if(in_array('rejeter_dossier'.$typeMenu,session('InfosAction'))): ?>
		<button type='button' class='btn btn-danger btn-label right waves-light' id='btn-rejeter'><i class='ri-loader-line label-icon align-middle fs-16 ms-2'></i> Rejeter le dossier</button>
	<?php endif; ?>
	<?php if(in_array('transmission_dossier'.$typeMenu,session('InfosAction'))): ?>
		<button type='button' class='btn btn-success btn-label right waves-light' id='btn-transmettre'><i class='ri-check-double-line label-icon align-middle fs-16 ms-2'></i> Transmettre</button>
	<?php endif; ?>
	<?php if(in_array('valider_dossier'.$typeMenu,session('InfosAction'))): ?>
		<button type='button' class='btn btn-success btn-label right waves-light' id='btn-valider'><i class='ri-check-double-line label-icon align-middle fs-16 ms-2'></i> Valider</button>
	<?php endif; ?>
	<?php if(in_array('affecter_dossier'.$typeMenu,session('InfosAction'))): ?>
		<button type='button' class='btn btn-warning btn-label right waves-light' id='btn-affecter'><i class=' ri-send-plane-2-line label-icon align-middle fs-16 ms-2'></i> Affecter à la session</button>
	<?php endif; ?>
	<table class="table table-striped table-bordered table-nowrap mt-4">
		<thead><tr>
			<th scope='col'></th>
			<th scope="col" class="text-center"><?php echo trans('data.agent_id'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.is_bourse'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.plan_id'); ?></th>
			<th scope="col" ><?php echo trans('data.etat_dossier'); ?></th>
			<?php if($typeMenu == 'pf'): ?>
				<th scope="col" class="text-center"><?php echo trans('data.avis_motive'); ?></th>
			<?php endif; ?>
			<th scope="col" class="text-center"><?php echo trans('data.entite_id'); ?></th>
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<?php  
					if(isset($listgiwu->dossier->agent) && $listgiwu->dossier->agent->is_bourse == '1'){
						$var = "<span class='badge bg-success'>".trans('entite.boursier')[$listgiwu->dossier->agent->is_bourse]."</span>";
					}else{ 
						$var = "<span class='badge bg-danger'>".trans('entite.boursier')[$listgiwu->dossier->agent->is_bourse]."</span>";
					} 
				?>
				<tr>
					<td class='text-center'><input class='form-check-input checkradio' data-id='<?php echo e($listgiwu->dossier->id_dossier); ?>' data-code='<?php echo e($listgiwu->dossier->code); ?>'  data-avis_moti='<?php echo e($listgiwu->dossier->avis_motive); ?>' data-typeme='<?php echo e($typeMenu); ?>' type='radio' name='formradiocolor9' id='formradioRight13'></td>
					<td><?php echo isset($listgiwu->dossier->agent) ? $listgiwu->dossier->agent->matricule_ag.' '.$listgiwu->dossier->agent->nom_ag.' '.$listgiwu->dossier->agent->prenom_ag : trans('data.not_found'); ?></td>
					<td class="text-center"><?php echo $var; ?></td>
					<td><?php echo isset($listgiwu->dossier->planformation) ? 'Réf : '.$listgiwu->dossier->planformation->ref_pf : trans('data.not_found'); ?></td>
					<td><?php echo trans('entite.etape_dossier')[$listgiwu->etat_trans]; ?></td>
					<?php if($typeMenu == 'pf'): ?>
						<td class="text-center">
							<?php if($listgiwu->dossier->avis_motive): ?>
								<a href='<?php echo e("assets/docs/".$listgiwu->dossier->avis_motive); ?>' title="<?php echo $listgiwu->dossier->avis_motive; ?>" target="_blank" class="badge bg-success">Ouvrir</a>
							<?php else: ?> <span class="badge bg-danger">Aucun</a>  <?php endif; ?>
						</td>
					<?php endif; ?>
					<td><?php echo isset($listgiwu->dossier->entite) ? $listgiwu->dossier->entite->sigle_entite : trans('data.not_found'); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\formation\resources\views/dossier/index-search.blade.php ENDPATH**/ ?>