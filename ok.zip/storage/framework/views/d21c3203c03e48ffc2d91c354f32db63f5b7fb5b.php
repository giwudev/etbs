<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
    <table class="table table-striped table-bordered table-nowrap">
        <thead>
            <tr>
                <!-- <th scope="col"><?php echo e(trans('data.id_role')); ?></th> -->
                <th scope="col"><?php echo e(trans('data.libelle_role')); ?></th>
                <th scope="col"><?php echo e(trans('data.user_save_id')); ?></th>
                <th scope="col"><?php echo e(trans('data.sous_role')); ?></th>
                <?php if(in_array('update_role',session('InfosAction')) || in_array('delete_role',session('InfosAction')) || in_array('add_action',session('InfosAction'))): ?>
                    <th class="text-center"> Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <!-- <td><?php echo e($listgiwu->id_role); ?></td> -->
                    <td><?php echo e($listgiwu->libelle_role); ?></td>
                    <td><?php echo e(isset($listgiwu->users_g) ? $listgiwu->users_g->name.' '.$listgiwu->users_g->prenom : trans('data.not_found')); ?></td>
                    <td><?php echo e(isset($listgiwu->sousrole) ? $listgiwu->sousrole->libelle_role : '--'); ?></td>
                    <?php if(in_array('update_role',session('InfosAction')) || in_array('delete_role',session('InfosAction')) || in_array('add_action',session('InfosAction'))): ?>
                        <td class="text-center">
                            <?php if(in_array('update_role',session('InfosAction'))): ?>
                                <a href="<?php echo e(route('role.edit',$listgiwu->id_role)); ?>" title='Modifier' class="btn btn-success btn-sm  waves-effect waves-light"><i class="ri-edit-2-line"></i></a>
                            <?php endif; ?>
                            <?php if(in_array('delete_role',session('InfosAction'))): ?>
                                <button type="button"  title='Supprimer' data-id="<?php echo e($listgiwu->id_role); ?>" class="btn btn-danger btn-sm  waves-effect waves-light btn-delete" data-bs-toggle="modal" ><i class="ri-delete-bin-6-line"></i></button>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo $list->appends([
        'query'=>(isset($_GET['query'])?$_GET['query']:'')
        ])->links(); ?>

<?php else: ?>
	<div class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\formation\resources\views/role/index-search.blade.php ENDPATH**/ ?>