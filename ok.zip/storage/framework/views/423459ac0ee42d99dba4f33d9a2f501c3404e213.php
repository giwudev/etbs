<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<table class="table table-striped table-bordered table-nowrap">
		<thead><tr>
			<!-- <th scope="col" class="text-center"><?php echo trans('data.annee_debut'); ?></th> -->
			<th scope="col" class="text-center"><?php echo trans('data.libelle_annee'); ?></th>
			<th scope="col" ><?php echo trans('data.statut_annee'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.etablis_id'); ?></th>
			<?php if(in_array('update_anneesco',session('InfosAction')) || in_array('delete_anneesco',session('InfosAction')) ): ?>
				<th class="text-center"> Actions</th>
			<?php endif; ?>
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<!-- <td style ='text-align:right' ><?php echo e(strrev(wordwrap(strrev(intval($listgiwu->annee_debut)), 3, ' ', true))); ?></td> -->
					<td class="text-center" ><?php echo e($listgiwu->annee_debut.' - '.$listgiwu->annee_fin); ?></td>
					<td class="text-center">
						<?php if($listgiwu->statut_annee == 'a'): ?><span class="badge bg-success"><?php echo e(trans('entite.statutanne')[$listgiwu->statut_annee]); ?></span> <?php else: ?> <span class="badge bg-danger"><?php echo e(trans('entite.statutanne')[$listgiwu->statut_annee]); ?></span> <?php endif; ?>
					</td>
					<td><?php echo isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found'); ?></td>
					<td><?php echo isset($listgiwu->ecole) ? $listgiwu->ecole->sigle_eco : trans('data.not_found'); ?></td>
					<?php if(in_array('update_anneesco',session('InfosAction')) || in_array('delete_anneesco',session('InfosAction')) ): ?>
						<td class="text-center">
							<?php if(in_array('update_anneesco',session('InfosAction'))): ?>
								<a href="<?php echo e(route('anneesco.edit',$listgiwu->id_annee)); ?>" title='Modifier' class="btn btn-success btn-sm  waves-effect waves-light"><i class="ri-edit-2-line"></i></a>
							<?php endif; ?>
							<?php if(in_array('delete_anneesco',session('InfosAction'))): ?>
								<button type="button"  title='Supprimer' data-id="<?php echo e($listgiwu->id_annee); ?>" class="btn btn-danger btn-sm  waves-effect waves-light btn-delete" data-bs-toggle="modal" ><i class="ri-delete-bin-6-line"></i></button>
							<?php endif; ?>
					<?php endif; ?>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\etbs\resources\views/anneesco/index-search.blade.php ENDPATH**/ ?>