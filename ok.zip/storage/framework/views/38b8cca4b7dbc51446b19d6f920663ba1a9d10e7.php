<div class="modal-content">
	<div class="modal-body text-center p-4">
		<div class="mt-2">
			<h4 class="mb-3" style="color:#D29C40" > Affectation du dossier à la session !</h4>
			<p class="text-muted mb-4"> Êtes-vous de vouloir affecter ce dossier à la session ? </p>
			<form action="<?php echo e(url('/dossier'.$typeMenu.'/affecterData/'.$item->id_dossier)); ?>" method="POST">
					<?php echo csrf_field(); ?>
				<button type="button" class="btn btn-light" data-bs-dismiss="modal">Non</button>
				<button id="submit" class="btn btn-warning">Oui</button>
			</form>
			<div class="hstack gap-2 justify-content-center"></div>
		</div>
	</div>
</div>
<?php /**PATH C:\wamp\www\formation\resources\views/dossier/affecter.blade.php ENDPATH**/ ?>