


<?php $__env->startSection('path_content'); ?>
	<?php if(sizeof($pathMenu) != 0): ?>
		<?php for($i=0; $i < count($pathMenu); $i++): ?>
            <li class="breadcrumb-item active"><a href="<?php echo e($pathMenu[$i]['lien']); ?>" class="kt-subheader__breadcrumbs-link"><?php echo e($pathMenu[$i]['titre']); ?></a></li>
		<?php endfor; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1"><?php echo e($titre); ?></h4>
                <div class="flex-shrink-0">
                    <div class="form-check form-switch form-switch-right form-switch-md">
                        <i class="<?php echo e($icone); ?>"></i>
                    </div>
                </div>
            </div><!-- end card header -->
            <div class="card-body">
                <p class="text-muted"></p>
                <div class="live-preview">
                <strong><div class="msgAjouter"></div></strong>
                    <form action="<?php echo e(route('role.update',$item->id_role)); ?>" method="post" id="form" class="row g-3 needs-validation" novalidate  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="row">
                            <?php if(session()->has('success') || session()->has('error')): ?>
                                <div class="col-md-12">
                                    <div class="alert <?php echo e(session()->has('success') ? 'alert-success' : ''); ?> <?php echo e(session()->has('error') ? 'alert-danger' : ''); ?> alert-border-left alert-dismissible fade show" role="alert">
                                        <i title ="<?php echo e(session()->has('errorMsg')? session()->get('errorMsg') : ''); ?>" class=" <?php echo e(session()->has('success') ? 'ri-notification-off-line' : 'ri-error-warning-line'); ?> me-3 align-middle"></i> <strong>Infos </strong> - <?php echo e(session()->has('success') ? session()->get('success') : session()->get('error')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <label for="libelle_role" class="form-label"><?php echo e(trans('data.libelle_role')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('libelle_role',$item->libelle_role,["id"=>"libelle_role","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer le role",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-12">
                                <table class="table table-striped table-bordered table-hover" id="sample_2" role="grid" aria-describedby="sample_2_info">
                                    <thead>
                                        <tr role="row" >
                                            <th>Choisir le menu</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $listMenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php  if(\App\Models\GiwuRoleAcces::getCheckRoleAcces($OneAcces->id_role,$list->id_menu) == 0){
                                                    $checkMenu = "";
                                                }else{
                                                    $checkMenu = "checked";
                                                } ?>
                                            <tr role="row">
                                                <td>                                                 
                                                    <div class="form-check form-switch">
                                                        <input class="form-check-input" <?php echo e($checkMenu); ?> type="checkbox" role="switch" id="flexSwitchCheckChecked<?php echo e($list->id_menu); ?>" name ="cocher<?php echo e($list->id_menu); ?>" value="<?php echo e($list->id_menu); ?>">
                                                        <label class="form-check-label" for="flexSwitchCheckChecked<?php echo e($list->id_menu); ?>">Menu : <?php echo e($list->libelle_menu); ?> / <?php echo e($list->titre_page); ?></label>
                                                    </div>
                                                </td>
                                            </tr>  
                                            <?php $cheActio = \App\Models\GiwuRoleAcces::getlistAction($list->id_menu);?>
                                            <?php if(sizeof($cheActio) != 0): ?>
                                                <?php $__currentLoopData = $cheActio; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listAct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php  if(\App\Models\GiwuActionmenuacces::getCheckActionAccesMenu($OneAcces->id_role,$list->id_menu,$listAct->id_action) == 0){
                                                        $checkAction = "";
                                                    }else{
                                                        $checkAction = "checked";
                                                    } ?>
                                                    <tr role="row" style="color:#61a7a3;">
                                                        <td style="padding-left:70px;">
                                                            <div class="form-check form-switch">
                                                                <input class="form-check-input" <?php echo e($checkAction); ?> type="checkbox" role="switch" name ="action<?php echo e($listAct->id_action); ?>"  value="<?php echo e($listAct->id_action); ?>" id="flexSwitchCheck<?php echo e($listAct->id_action); ?>" >
                                                                <label class="form-check-label" for="flexSwitchCheck<?php echo e($listAct->id_action); ?>">Actions : <?php echo e($listAct->libelle_action); ?></label>
                                                            </div>
                                                        </td>
                                                    </tr>  
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="col-12">
                                <div class="text-end">
                                    <a href="<?php echo e(route('role.index')); ?>" class="btn btn-outline-dark waves-effect mr-10">Fermer</a>
                                    <?php if(in_array('update_role',session('InfosAction'))): ?>
                                        <button type="submit" class="btn btn-success btn-label right"><i class="ri-edit-2-line label-icon align-middle fs-16 ms-2"></i>Modifier</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div><!--end row-->
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\etbs\resources\views/role/edit.blade.php ENDPATH**/ ?>