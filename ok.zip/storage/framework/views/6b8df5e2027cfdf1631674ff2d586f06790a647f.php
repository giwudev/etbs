
<!-- auth-bg-cover -->
<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">


<!-- Mirrored from themesbrand.com/velzon/html/default/landing.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 13:33:24 GMT -->
<head>

    <meta charset="utf-8" />
    <title>Site</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!--Swiper slider css-->
    <link href="assets/libs/swiper/swiper-bundle.min.css" rel="stylesheet" type="text/css" />

    <!-- Layout config Js -->
    <script src="assets/js/layout.js"></script>
    <!-- Bootstrap Css -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="assets/css/app.min.css" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href="assets/css/custom.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
</head>

<body data-bs-spy="scroll" data-bs-target="#navbar-example">

    <!-- Begin page -->
    <div class="layout-wrapper landing">
        <nav class="navbar navbar-expand-lg navbar-landing fixed-top" id="navbar">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="assets/images/logo-mtfpas.png" class="card-logo card-logo-dark" alt="logo dark" height="50">
                    <img src="assets/images/logo-mtfpas.png" class="card-logo card-logo-light" alt="logo light" height="50">
                </a>
                <button class="navbar-toggler py-0 fs-20 text-body" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="mdi mdi-menu"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto mt-2 mt-lg-0" id="navbar-example">
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(url('/')); ?>">Accueil</a>
                        </li>
                        <!-- <li class="nav-item">
                            <a class="nav-link" href="#planformation">Plan de formation</a>
                        </li> -->
                        <?php if(isset(session('InfosAgent')->nom_ag)): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/mypage')); ?>">Mon espace</a>
                            </li> 
                        <?php endif; ?>
                    </ul>
                    <div class="">
                        <a href="<?php echo e(url('logoutAgent')); ?>" class="btn btn-success">Déconnectez-vous</a>
                    </div>
                </div>
            </div>
        </nav>
        <!-- end navbar -->
        <div class="vertical-overlay" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent.show"></div>

        
        <div class="page-content">
                <div class="container-fluid">
                    <div class="profile-foreground position-relative mx-n4 mt-n4">
                        <div class="profile-wid-bg">
                            <img src="<?php echo e(url('assets/images/profile-bg.png')); ?>" alt="" class="profile-wid-img" />
                        </div>
                    </div>
                    <div class="pt-4 mb-4 mb-lg-3 pb-lg-4">
                        <div class="row g-4">
                            <div class="col-auto">
                                <div class="avatar-lg">
                                    <img src="assets/images/user/avatar-1.jpg" alt="user-img" class="img-thumbnail rounded-circle" />
                                </div>
                            </div>
                            <!--end col-->
                            <div class="col">
                                <div class="p-2">
                                    <h3 class="text-white mb-1"><?php echo e(session('InfosAgent')->nom_ag.' '.session('InfosAgent')->prenom_ag); ?> (<?php echo e(session('InfosAgent')->matricule_ag); ?>)</h3>
                                    <p class="text-white-75"><?php echo e(session('InfosAgent')->entite->libelle_entite); ?></p>
                                    <div class="hstack text-white-50 gap-1">
                                        <!-- <div class="me-2"><i class="ri-map-pin-user-line me-1 text-white-75 fs-16 align-middle"></i>California, United States</div> -->
                                        <div>
                                            <i class="ri-phone-line me-1 text-white-75 fs-16 align-middle"></i><?php echo e(session('InfosAgent')->tel_ag.' - '.session('InfosAgent')->mail_ag); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--end col-->
                            <!-- <div class="col-12 col-lg-auto order-last order-lg-0">
                                <div class="row text text-white-50 text-center">
                                    <div class="col-lg-6 col-4">
                                        <div class="p-2">
                                            <h4 class="text-white mb-1">24.3K</h4>
                                            <p class="fs-14 mb-0">Followers</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-4">
                                        <div class="p-2">
                                            <h4 class="text-white mb-1">1.3K</h4>
                                            <p class="fs-14 mb-0">Following</p>
                                        </div>
                                    </div>
                                </div>
                            </div> -->
                            <!--end col-->

                        </div>
                        <!--end row-->
                    </div>

                    <div class="row">
                        <div class="col-lg-12">
                            <div>
                                <div class="d-flex">
                                    <!-- Nav tabs -->
                                    <ul class="nav nav-pills animation-nav profile-nav gap-2 gap-lg-3 flex-grow-1" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link fs-14 active" data-bs-toggle="tab" href="#projects" role="tab">
                                                <i class="ri-list-unordered d-inline-block d-md-none"></i> <span class="d-none d-md-inline-block">Dossier de formation</span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link fs-14 " data-bs-toggle="tab" href="#miseEnStage" role="tab">
                                                <i class="ri-price-tag-line d-inline-block d-md-none"></i> <span class="d-none d-md-inline-block">Dossier de Mise en stage</span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link fs-14" data-bs-toggle="tab" href="#RetourEnStage" role="tab">
                                                <i class="ri-folder-4-line d-inline-block d-md-none"></i> <span class="d-none d-md-inline-block">Dossier de Retour de stage</span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="flex-shrink-0">
                                        <!-- <a href="pages-profile-settings.html" class="btn btn-success"><i class="ri-edit-box-line align-bottom"></i> Edit Profile</a> -->
                                    </div>
                                </div>
                                <!-- Tab panes -->
                                <div class="tab-content pt-4 text-muted">
                                    <!--end tab-pane-->
                                    <div class="tab-pane active" id="projects" role="tabpanel">
                                        <div class="card">
                                            <div class="card-body">
                                                <h5 class="card-title flex-grow-1 mb-0">Dossier de formation</h5><br>
                                                <!-- foreach -->
                                                <?php if(count($listPF) != 0): ?>
                                                    <div class="row">
                                                        <?php $__currentLoopData = $listPF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($list->planformation->etat_pf == "a"){$color = 'success';}else{$color = 'danger'; } ?>
                                                            <div class="col-xxl-6 col-sm-6">
                                                                <div class="card profile-project-card shadow-none profile-project-<?php echo e($color); ?>">
                                                                    <div class="card-body p-4">
                                                                        <div class="d-flex">
                                                                            <div class="flex-grow-1 text-muted overflow-hidden">
                                                                                <h5 class="fs-14 text-truncate"><a href="#" class="text-dark"><?php echo e(trans('data.reference')); ?> : <?php echo e($list->planformation->ref_pf); ?></a></h5>
                                                                                <p class="text-muted text-truncate mb-0">
                                                                                    <span class="fw-semibold text-dark">Du </span> <?php echo e(date('d/m/Y',strtotime($list->date_debu_pf))); ?>

                                                                                    <span class="fw-semibold text-dark"> au </span> <?php echo e(date('d/m/Y',strtotime($list->date_fin_pf))); ?>

                                                                                </p>
                                                                                <span class="fw-semibold text-dark"> <?php echo e(trans('data.formation')); ?> :  </span> <?php echo e($list->formation->libelle_form); ?> <br>
                                                                                <span class="fw-semibold text-dark"> <?php echo e(trans('data.structure')); ?> :  </span> <?php echo e($list->structureformatrice->libelle_str); ?>

                                                                            </div>
                                                                            <div class="flex-shrink-0 ms-2">
                                                                                <div class="badge badge-soft-<?php echo e($color); ?>  fs-10">Etat : <?php echo e(trans('entite.etat_plan')[$list->planformation->etat_pf]); ?></div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="d-flex mt-4">
                                                                            <div class="flex-grow-1">
                                                                                <div class="d-flex align-items-center gap-2">
                                                                                    <?php if(isset($list->planformation->fichier_plan)): ?>
                                                                                        <div>
                                                                                            <a class="badge badge-soft-primary fs-10" href='<?php echo e("assets/docs/".$list->planformation->fichier_plan); ?>' target="_blank" role="button">Consulter le fichier</a>
                                                                                        </div>
                                                                                    <?php endif; ?>
                                                                                </div>
                                                                            </div>
                                                                            <div class="flex-shrink-0 ms-2">
                                                                                <?php $check = \App\Models\Dossier::CheckDossierAgent($list->planformation->id_pf,'pf'); ?>
                                                                                <?php if($list->planformation->etat_pf == "a"): ?>
                                                                                    <?php if(!isset($check)): ?>
                                                                                        <a class="btn btn-primary btn-add" data-id='<?php echo e($list->planformation->id_pf); ?>' data-type='pf' href="#" title="Soumettre mon dossier de mise en stage" role="button">Soumettre</a>
                                                                                    <?php else: ?>
                                                                                        <a class="btn btn-outline-warning waves-effect waves-light btn-suivre" data-id='<?php echo e($check->id_dossier); ?>'title="Suivre mon dossier"  href="#" role="button">Suivre</a>
                                                                                    <?php endif; ?>
                                                                                <?php elseif(isset($check) && $list->planformation->etat_pf == "c"): ?>
                                                                                    <a class="btn btn-outline-primary waves-effect waves-light btn-suivre" data-id='<?php echo e($check->id_dossier); ?>'title="Parcours de mon dossier"  href="#" role="button">Parcours</a>
                                                                                <?php else: ?>
                                                                                    <div class="badge badge-soft-<?php echo e($color); ?>  fs-10">Vous n'aviez pas soumis</div>
                                                                                <?php endif; ?>
                                                                                
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <!-- end card body -->
                                                                </div>
                                                                <!-- end card -->
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php else: ?>
                                                    <div Class="alert alert-info"><strong>Info! </strong> Aucun dossier de formation plan de formation n'a été associé à votre compte. </div>
                                                <?php endif; ?>
                                                <!--end row-->
                                            </div>
                                            <!--end card-body-->
                                        </div>
                                        <!--end card-->
                                    </div>
                                    <!--end tab-pane-->
                                    <div class="tab-pane fade" id="miseEnStage" role="tabpanel">
                                        <div class="card">
                                            <div class="card-body">
                                                <h5 class="card-title flex-grow-1 mb-0">Mise en stage</h5><br>
                                                <!-- foreach -->
                                                <?php if(count($listPF) != 0): ?>
                                                <div class="row">
                                                    <?php $__currentLoopData = $listPF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($list->planformation->etat_pf == "a"){$color = 'success';}else{$color = 'danger'; } ?>
                                                        <?php $check = \App\Models\Dossier::CheckDossierAgent($list->planformation->id_pf,'ms'); ?>
                                                        <div class="col-xxl-6 col-sm-6">
                                                            <div class="card profile-project-card shadow-none profile-project-<?php echo e($color); ?>">
                                                                <div class="card-body p-4">
                                                                    <div class="d-flex">
                                                                        <div class="flex-grow-1 text-muted overflow-hidden">
                                                                            <h5 class="fs-14 text-truncate"><a href="#" class="text-dark"><?php echo e(trans('data.reference')); ?> : <?php echo e($list->planformation->ref_pf); ?></a></h5>
                                                                            <p class="text-muted text-truncate mb-0">
                                                                                <span class="fw-semibold text-dark">Du </span> <?php echo e(date('d/m/Y',strtotime($list->date_debu_pf))); ?>

                                                                                <span class="fw-semibold text-dark"> au </span> <?php echo e(date('d/m/Y',strtotime($list->date_fin_pf))); ?>

                                                                            </p>
                                                                            <span class="fw-semibold text-dark"> <?php echo e(trans('data.formation')); ?> :  </span> <?php echo e($list->formation->libelle_form); ?> <br>
                                                                            <span class="fw-semibold text-dark"> <?php echo e(trans('data.structure')); ?> :  </span> <?php echo e($list->structureformatrice->libelle_str); ?>

                                                                        </div>
                                                                        <div class="flex-shrink-0 ms-2">
                                                                            <div class="badge badge-soft-<?php echo e($color); ?>  fs-10">Etat : <?php echo e(trans('entite.etat_plan')[$list->planformation->etat_pf]); ?></div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="d-flex mt-4">
                                                                        <div class="flex-grow-1">
                                                                            <div class="d-flex align-items-center gap-2">
                                                                                <?php if(isset($check) && $check->fichier_decision != ''): ?>
                                                                                    <div>
                                                                                        <a class="badge badge-soft-primary fs-10" href='<?php echo e("assets/docs/".$check->fichier_decision); ?>' target="_blank" role="button">Télécharger la décision</a>
                                                                                    </div>
                                                                                <?php endif; ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="flex-shrink-0 ms-2">
                                                                            <?php if($list->planformation->etat_pf == "a"): ?>
                                                                                <?php if(!isset($check)): ?>
                                                                                    <a class="btn btn-primary btn-add" data-id='<?php echo e($list->planformation->id_pf); ?>' data-type='ms' href="#" title="Soumettre mon dossier de mise en stage" role="button">Soumettre</a>
                                                                                <?php else: ?>
                                                                                    <a class="btn btn-outline-warning waves-effect waves-light btn-suivre" data-id='<?php echo e($check->id_dossier); ?>'title="Suivre mon dossier"  href="#" role="button">Suivre</a>
                                                                                <?php endif; ?>
                                                                            <?php elseif(isset($check) && $list->planformation->etat_pf == "c"): ?>
                                                                                <a class="btn btn-outline-primary waves-effect waves-light btn-suivre" data-id='<?php echo e($check->id_dossier); ?>'title="Parcours de mon dossier"  href="#" role="button">Parcours</a>
                                                                            <?php else: ?>
                                                                                <div class="badge badge-soft-<?php echo e($color); ?>  fs-10">Vous n'aviez pas soumis</div>
                                                                            <?php endif; ?>
                                                                            
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- end card body -->
                                                            </div>
                                                            <!-- end card -->
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                
                                                <?php else: ?>
                                                    <div Class="alert alert-info"><strong>Info! </strong> Aucun dossier de formation n'a été associé à votre compte. </div>
                                                <?php endif; ?>
                                                <!--end row-->
                                            </div>
                                            <!--end card-body-->
                                        </div>
                                        <!--end card-->
                                    </div>
                                    
                                    <!--end tab-pane-->
                                    <div class="tab-pane fade" id="RetourEnStage" role="tabpanel">
                                        <div class="card">
                                            <div class="card-body">
                                                <h5 class="card-title flex-grow-1 mb-0">Retour de stage </h5><br>
                                                <?php if(count($listPF) != 0): ?>
                                                <div class="row">
                                                    <?php $__currentLoopData = $listPF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($list->planformation->etat_pf == "a"){$color = 'success';}else{$color = 'danger'; } ?>
                                                        <?php $check = \App\Models\Dossier::CheckDossierAgent($list->planformation->id_pf,'rs'); ?>
                                                        <div class="col-xxl-6 col-sm-6">
                                                            <div class="card profile-project-card shadow-none profile-project-<?php echo e($color); ?>">
                                                                <div class="card-body p-4">
                                                                    <div class="d-flex">
                                                                        <div class="flex-grow-1 text-muted overflow-hidden">
                                                                            <h5 class="fs-14 text-truncate"><a href="#" class="text-dark"><?php echo e(trans('data.reference')); ?> : <?php echo e($list->planformation->ref_pf); ?></a></h5>
                                                                            <p class="text-muted text-truncate mb-0">
                                                                                <span class="fw-semibold text-dark">Du </span> <?php echo e(date('d/m/Y',strtotime($list->date_debu_pf))); ?>

                                                                                <span class="fw-semibold text-dark"> au </span> <?php echo e(date('d/m/Y',strtotime($list->date_fin_pf))); ?>

                                                                            </p>
                                                                            <span class="fw-semibold text-dark"> <?php echo e(trans('data.formation')); ?> :  </span> <?php echo e($list->formation->libelle_form); ?> <br>
                                                                            <span class="fw-semibold text-dark"> <?php echo e(trans('data.structure')); ?> :  </span> <?php echo e($list->structureformatrice->libelle_str); ?>

                                                                        </div>
                                                                        <div class="flex-shrink-0 ms-2">
                                                                            <div class="badge badge-soft-<?php echo e($color); ?>  fs-10">Etat : <?php echo e(trans('entite.etat_plan')[$list->planformation->etat_pf]); ?></div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="d-flex mt-4">
                                                                        <div class="flex-grow-1">
                                                                            <div class="d-flex align-items-center gap-2">
                                                                                <!-- <?php if(isset($check) && $check->fichier_decision != ''): ?>
                                                                                    <div>
                                                                                        <a class="badge badge-soft-primary fs-10" href='<?php echo e("assets/docs/".$check->fichier_decision); ?>' target="_blank" role="button">Télécharger la décision</a>
                                                                                    </div>
                                                                                <?php endif; ?> -->
                                                                            </div>
                                                                        </div>
                                                                        <div class="flex-shrink-0 ms-2">
                                                                            <?php if($list->planformation->etat_pf == "a"): ?>
                                                                                <?php if(!isset($check)): ?>
                                                                                    <a class="btn btn-primary btn-add" data-id='<?php echo e($list->planformation->id_pf); ?>' data-type='rs' href="#" title="Soumettre mon dossier de retour de stage" role="button">Soumettre</a>
                                                                                <?php else: ?>
                                                                                    <a class="btn btn-outline-warning waves-effect waves-light btn-suivre" data-id='<?php echo e($check->id_dossier); ?>'title="Suivre mon dossier"  href="#" role="button">Suivre</a>
                                                                                <?php endif; ?>
                                                                            <?php elseif(isset($check) && $list->planformation->etat_pf == "c"): ?>
                                                                                <a class="btn btn-outline-primary waves-effect waves-light btn-suivre" data-id='<?php echo e($check->id_dossier); ?>'title="Parcours de mon dossier"  href="#" role="button">Parcours</a>
                                                                            <?php else: ?>
                                                                                <div class="badge badge-soft-<?php echo e($color); ?>  fs-10">Vous n'aviez pas soumis</div>
                                                                            <?php endif; ?>
                                                                            
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <!-- end card body -->
                                                            </div>
                                                            <!-- end card -->
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                
                                                <?php else: ?>
                                                    <div Class="alert alert-info"><strong>Info! </strong> Aucun dossier de formation n'a été associé à votre compte. </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end tab-pane-->
                                </div>
                                <!--end tab-content-->
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->

                </div><!-- container-fluid -->
            </div><!-- End Page-content -->



        <!--begin::Modifier-->
        <div><div class="modal fade bs-example-modal-center" data-bs-backdrop='static' id="kt_add_4" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" role="dialog" >
            <div class="modal-dialog modal-lg modal-dialog-scrollable"></div>
        </div></div>

        <!-- Start footer -->
        <footer class="custom-footer bg-dark py-5 position-relative">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 mt-4">
                        <div>
                            <div>
                                <img src="assets/images/logo-mtfpas.png" alt="logo light" height="45">
                            </div>
                            <div class="mt-4 fs-13">
                                <p>Plan de formation</p>
                                <p class="ff-secondary">La direction générale de l'administration et de la fonction publique (DGAFP) 
                                        élabore un schéma directeur triennal de la politique de formation professionnelle tout au long de la vie des agents de l'Etat. 
                                            Ce schéma définit les priorités de formation dans les domaines communs à l'ensemble des ministères.</p>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-7 ms-lg-auto">
                        <div class="row">
                            <div class="col-sm-6 mt-4">
                                <h5 class="text-white mb-0">Liens rapides </h5>
                                <div class="text-muted mt-3">
                                    <ul class="list-unstyled ff-secondary footer-list">
                                        <li><a href="#">Site Web</a></li>
                                        <li><a href="#">Gallery</a></li>
                                    </ul>
                                </div>
                            </div>
                           
                            <div class="col-sm-6 mt-4">
                                <h5 class="text-white mb-0">Support</h5>
                                <div class="text-muted mt-3">
                                    <ul class="list-unstyled ff-secondary footer-list">
                                        <li><a href="#">FAQ</a></li>
                                        <li><a href="#">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="row text-center text-sm-start align-items-center mt-5">
                    <div class="col-sm-6">

                        <div>
                            <p class="copy-rights mb-0">
                                <script> document.write(new Date().getFullYear()) </script> © PF
                            </p>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="text-sm-end mt-3 mt-sm-0">
                            <ul class="list-inline mb-0 footer-social-link">
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-facebook-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-github-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-linkedin-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-google-fill"></i>
                                        </div>
                                    </a>
                                </li>
                                <li class="list-inline-item">
                                    <a href="javascript: void(0);" class="avatar-xs d-block">
                                        <div class="avatar-title rounded-circle">
                                            <i class="ri-dribbble-line"></i>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end footer -->


        <!--start back-to-top-->
        <button onclick="topFunction()" class="btn btn-danger btn-icon landing-back-top" id="back-to-top">
            <i class="ri-arrow-up-line"></i>
        </button>
        <!--end back-to-top-->

    </div>
    <!-- end layout wrapper -->

    <?php echo $__env->yieldContent('JS_content'); ?>
    <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
    <!-- JAVASCRIPT -->
    <script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/libs/simplebar/simplebar.min.js"></script>
    <script src="assets/libs/node-waves/waves.min.js"></script>
    <script src="assets/libs/feather-icons/feather.min.js"></script>
    <script src="assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
    <script src="assets/js/plugins.js"></script>

    <!--Swiper slider js-->
    <script src="assets/libs/swiper/swiper-bundle.min.js"></script>

    <!-- landing init -->
    <script src="assets/js/pages/landing.init.js"></script>
    
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('.allselect').select2();
        });
        
        $(document).on('click', '.btn-add', function () {
            var id = $(this).data('id');
            var typ_ = $(this).data('type');
			$.ajax({url : '<?php echo e(url("createdoss")); ?>/'+id+'/'+typ_,type : 'GET',dataType : 'html',
				success : function(code_html, statut){$('#kt_add_4 .modal-dialog').html(code_html);$('#kt_add_4').modal('show');}
			});
		});
        
        $(document).on('click', '.btn-suivre', function () {
            var id = $(this).data('id');
			$.ajax({url : '<?php echo e(url("ParcoursDossier")); ?>/'+id,type : 'GET',dataType : 'html',
				success : function(code_html, statut){$('#kt_add_4 .modal-dialog').html(code_html);$('#kt_add_4').modal('show');}
			});
		});
    </script>
</body>


<!-- Mirrored from themesbrand.com/velzon/html/default/landing.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 14 Dec 2022 13:33:55 GMT -->
</html>
<?php /**PATH C:\wamp\www\formation\resources\views/site/agent/espace.blade.php ENDPATH**/ ?>