<meta name='csrf-token' content='<?php echo e(csrf_token()); ?>'>

<div class="modal-content">
	<div class="modal-header card-header"><h5 class="modal-title" id="varyingcontentModalLabel"><i class="<?php echo e($icone); ?>"></i>  <?php echo e($titre); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
		<div class="modal-body"><strong><div class="msgAction"></div></strong>
			<form id="formAction" class="needs-validation"  method="post" novalidate >
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-6">
						<div class="mb-3">
							<label for="plan_id" class="form-label"><?php echo trans('data.plan_id'); ?> <strong style='color: red;'> *</strong></label>
							<?php $addUse = array(''=>'S&eacute;lectionnez un &eacute;l&eacute;ment'); $listplan_id = $addUse + $listplan_id->toArray();?>
							<?php echo Form::select('plan_id',$listplan_id ,session('plan_idSess'),["id"=>"plan_id","class"=>"form-select allselect"]); ?>

							<span class="text-danger" id="plan_idError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="agent_id" class="form-label"><?php echo trans('data.agent_id'); ?> <strong style='color: red;'> *</strong></label>
							<?php $addUse = array(''=>'S&eacute;lectionnez un &eacute;l&eacute;ment'); $listagent_id = $addUse + $listagent_id->toArray();?>
							<?php echo Form::select('agent_id',$listagent_id ,null,["id"=>"agent_id","class"=>"form-select allselect"]); ?>

							<span class="text-danger" id="agent_idError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="formation_id" class="form-label"><?php echo trans('data.formation_id'); ?> <strong style='color: red;'> *</strong></label>
							<?php $addUse = array(''=>'S&eacute;lectionnez un &eacute;l&eacute;ment'); $listformation_id = $addUse + $listformation_id->toArray();?>
							<?php echo Form::select('formation_id',$listformation_id ,null,["id"=>"formation_id","class"=>"form-select allselect"]); ?>

							<span class="text-danger" id="formation_idError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="structure_id" class="form-label"><?php echo trans('data.structure_id'); ?> <strong style='color: red;'> *</strong></label>
							<?php $addUse = array(''=>'S&eacute;lectionnez un &eacute;l&eacute;ment'); $liststructure_id = $addUse + $liststructure_id->toArray();?>
							<?php echo Form::select('structure_id',$liststructure_id ,null,["id"=>"structure_id","class"=>"form-select allselect"]); ?>

							<span class="text-danger" id="structure_idError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="date_debu_pf" class="form-label"><?php echo trans('data.date_debu_pf'); ?> <strong style='color: red;'> *</strong></label>
							<?php echo Form::date('date_debu_pf',date('Y-m-d'),["id"=>"date_debu_pf","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Date debut" ]); ?>

							<span class="text-danger" id="date_debu_pfError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="date_fin_pf" class="form-label"><?php echo trans('data.date_fin_pf'); ?> <strong style='color: red;'> *</strong></label>
							<?php echo Form::date('date_fin_pf',date('Y-m-d'),["id"=>"date_fin_pf","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Date fin" ]); ?>

							<span class="text-danger" id="date_fin_pfError"></span>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-dark waves-effect waves-light" data-bs-dismiss="modal">Femer</button>
					<?php if(in_array('add_associeragent',session('InfosAction'))): ?>
						<button id="valider" type="button"  class="btn btn-primary btn-label right btn-load" onclick="addAction();">
							<span class="d-flex align-items-center"><span class="flex-grow-1 me-2">Ajouter</span><span class="flex-shrink-0" role="status"></span></span>
							<i class="ri-add-line label-icon align-middle fs-16 ms-2"></i>
						</button>
					<?php endif; ?>
				</div>
			</form>
		</div>
	</div>
	<script type="text/javascript"> $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}}); </script>

	<script type="text/javascript">
		function addAction(){

			$('#valider').attr("disabled",!0);
			$('#valider .flex-shrink-0').addClass("spinner-border");
			$("div.msgAction").html('').hide(200);
			$('#plan_idError').addClass('d-none');
			$('#date_debu_pfError').addClass('d-none');
			$('#date_fin_pfError').addClass('d-none');
			$('#agent_idError').addClass('d-none');
			$('#formation_idError').addClass('d-none');
			$('#structure_idError').addClass('d-none');
			var form = $('#formAction')[0];
			var data = new FormData(form);
			$.ajax({
				type: 'POST',url: '<?php echo e(url("/associeragent/")); ?>',
				enctype:'multipart/form-data',data: data,processData: false,contentType: false,
				success: function(data) {
					$('#valider').attr("disabled",!1);
					$('#valider .flex-shrink-0').removeClass("spinner-border");
					if(data.response==1){
						$("div.msgAction").html('<div class="alert alert-success alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Infos </strong> Enregistrement r&eacute;ussi. </div>').show(200);
						window.location.reload();
					}else if(data.response==0){
						$("div.msgAction").html('<div class="alert alert-danger alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Echec de l\'enregistrement</strong> '+data.message+'</div>').show(200);
					}else{
						$.each(data.response, function(Key, value){
							var ErrorID = '#'+Key+'Error';
							$(ErrorID).removeClass('d-none');
							$(ErrorID).text(value);
						})
					}
				},error: function(data) {}
			});
		}
	</script>

<?php /**PATH C:\wamp\www\formation\resources\views/associeragent/create.blade.php ENDPATH**/ ?>