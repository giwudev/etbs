


<?php $__env->startSection('path_content'); ?>
	<?php if(sizeof($pathMenu) != 0): ?>
		<?php for($i=0; $i < count($pathMenu); $i++): ?>
            <li class="breadcrumb-item active"><a href="<?php echo e($pathMenu[$i]['lien']); ?>" class="kt-subheader__breadcrumbs-link"><?php echo e($pathMenu[$i]['titre']); ?></a></li>
		<?php endfor; ?>
	<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1"><?php echo e($titre); ?></h4>
                <div class="flex-shrink-0">
                    <div class="form-check form-switch form-switch-right form-switch-md">
                    <i class="<?php echo e($icone); ?>"></i>
                    </div>
                </div>
            </div><!-- end card header -->
            <div class="card-body">
                <p class="text-muted"></p>
                <div class="live-preview">
                <strong><div class="msgAjouter"></div></strong>
                    <form action="<?php echo e(route('menu.update',$menu->id_menu)); ?>" method="post" id="form" class="row g-3 needs-validation" novalidate  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="row">
                            <?php if(session()->has('success') || session()->has('error')): ?>
                                <div class="col-md-12">
                                    <div class="alert <?php echo e(session()->has('success') ? 'alert-success' : ''); ?> <?php echo e(session()->has('error') ? 'alert-danger' : ''); ?> alert-border-left alert-dismissible fade show" role="alert">
                                        <i title ="<?php echo e(session()->has('errorMsg')? session()->get('errorMsg') : ''); ?>" class=" <?php echo e(session()->has('success') ? 'ri-notification-off-line' : 'ri-error-warning-line'); ?> me-3 align-middle"></i> <strong>Infos </strong> - <?php echo e(session()->has('success') ? session()->get('success') : session()->get('error')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="libelle_menu" class="form-label"><?php echo e(trans('data.libelle_menu')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('libelle_menu',$menu->libelle_menu,["id"=>"libelle_menu","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer le menu",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="titre_page" class="form-label"><?php echo e(trans('data.titre_page')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('titre_page',$menu->titre_page,["id"=>"titre_page","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer votre titre de la page",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="route" class="form-label"><?php echo e(trans('data.route')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('route',$menu->route,["id"=>"route","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer votre la route",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="menu_icon" class="form-label"><?php echo e(trans('data.menu_icon')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('menu_icon',$menu->menu_icon,["id"=>"menu_icon","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer votre l'îcone",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="num_ordre" class="form-label"><?php echo e(trans('data.num_ordre')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::number('num_ordre',$menu->num_ordre,["id"=>"num_ordre","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer le numéro d'ordre",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="topmenu_id" class="form-label"><?php echo e(trans('data.topmenu_id')); ?></label>
                                    <?php $addUse = array('0'=>'Sélectionner un élément'); $SltEmpMenu = $addUse + $SltEmpMenu->toArray();?>
                                    <?php echo Form::select('topmenu_id',$SltEmpMenu ,$menu->topmenu_id,["id"=>"topmenu_id","class"=>"form-control"]); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="architecture" class="form-label"><?php echo e(trans('data.architecture')); ?><strong style='color: red;'> *</strong></label>
                                    <?php echo Form::text('architecture',$menu->architecture,["id"=>"architecture","class"=>"form-control","required"=>"required",'placeholder'=>"Entrer le numéro d'ordre",'autocomplete'=>'off']); ?>

                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="elmt_menu" class="form-label"><?php echo e(trans('data.elmt_menu')); ?><strong style='color: red;'> *</strong></label>
                                    <?php $addUse = array(''=>'Sélectionner un élément','oui'=>'Oui','non'=>'Non'); ?>
						            <?php echo Form::select('elmt_menu',$addUse ,$menu->elmt_menu,["id"=>"elmt_menu","class"=>"form-select",'required'=>'required']); ?>

                                </div>
                            </div>
                            <div class="col-12">
                                <div class="text-end">
                                    <a href="<?php echo e(route('menu.index')); ?>" class="btn btn-outline-dark waves-effect mr-10">Fermer</a>
                                    <?php if(in_array('update_menu',session('InfosAction'))): ?>
                                        <button type="submit" class="btn btn-success btn-label right"><i class="ri-edit-2-line label-icon align-middle fs-16 ms-2"></i>Modifier</button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div><!--end row-->
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.general', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\formation\resources\views/menu/edit.blade.php ENDPATH**/ ?>