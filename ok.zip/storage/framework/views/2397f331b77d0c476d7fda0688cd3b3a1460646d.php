<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<?php if(in_array('update_planformation',session('InfosAction')) || in_array('delete_planformation',session('InfosAction')) || in_array('proces_planformation',session('InfosAction')) ): ?>
		<?php if(in_array('update_planformation',session('InfosAction'))): ?>
			<button type='button' class='btn btn-success btn-label right waves-light' id='btn-modifier'><i class='ri-check-double-line label-icon align-middle fs-16 ms-2'></i> Modifier</button>
		<?php endif; ?>
		<?php if(in_array('delete_planformation',session('InfosAction'))): ?>
			<button type='button' class='btn btn-danger btn-label right waves-light' id='btn-supprimer'><i class='ri-delete-bin-6-line label-icon align-middle fs-16 ms-2'></i> Supprimer</button>
		<?php endif; ?>
		<?php if(in_array('proces_planformation',session('InfosAction'))): ?>
			<button type='button' class='btn btn-success btn-label right waves-light' id='btn-proces'><i class=' ri-hammer-line label-icon align-middle fs-16 ms-2'></i> Faire un procès-verbal</button>
		<?php endif; ?>
	<?php endif; ?>
	<table class="table table-striped table-bordered table-nowrap mt-4">
		<thead><tr>
			<th scope='col'></th>
			<th scope="col" ><?php echo trans('data.ref_pf'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_debu_pf'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_fin_pf'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_sign_pf'); ?></th>
			<th scope="col" ><?php echo trans('data.etat_pf'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.entite_id'); ?></th>
			<!-- <th scope="col" class="text-center"><?php echo trans('data.formation_id'); ?></th> -->
			<!-- <th scope="col" class="text-center"><?php echo trans('data.structure_id'); ?></th> -->
			<th scope="col" class="text-center"><?php echo trans('data.fichier_plan'); ?></th>
			<?php if(session('InfosRole')->id_role == '14'): ?>
			<th scope="col" class="text-center"><?php echo trans('data.fichier_proces'); ?></th>
			<?php endif; ?>
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td class='text-center'><input class='form-check-input checkradio' data-id='<?php echo e($listgiwu->id_pf); ?>'  type='radio' name='formradiocolor9' id='formradioRight13'></td>
					<td><?php echo $listgiwu->ref_pf; ?></td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_debu_pf))); ?></td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_fin_pf))); ?></td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_sign_pf))); ?></td>
					<td class="text-center">
                        <?php if($listgiwu->etat_pf == 'a'): ?><span class="badge bg-success"><?php echo e(trans('entite.etat_plan')[$listgiwu->etat_pf]); ?></span> <?php else: ?> <span class="badge bg-danger"><?php echo e(trans('entite.etat_plan')[$listgiwu->etat_pf]); ?></span> <?php endif; ?>
                    </td>
					<td><?php echo isset($listgiwu->entite) ? $listgiwu->entite->sigle_entite : trans('data.not_found'); ?></td>
					<!-- <td><?php echo isset($listgiwu->formation) ? $listgiwu->formation->libelle_form : trans('data.not_found'); ?></td> -->
					<!-- <td><?php echo isset($listgiwu->structureformatrice) ? $listgiwu->structureformatrice->sigle_str : trans('data.not_found'); ?></td> -->
					<td class="text-center">
						<?php if($listgiwu->fichier_plan): ?>
							<a href='<?php echo e("assets/docs/".$listgiwu->fichier_plan); ?>' title="<?php echo $listgiwu->fichier_plan; ?>" target="_blank" class="badge bg-success">Ouvrir</a>
						<?php else: ?> <span class="badge bg-danger">Aucun</a>  <?php endif; ?>
					</td>
					<?php if(session('InfosRole')->id_role == '14'): ?>
						<td class="text-center">
							<?php if($listgiwu->fichier_proces): ?>
								<a href='<?php echo e("assets/docs/".$listgiwu->fichier_proces); ?>' title="<?php echo $listgiwu->fichier_proces; ?>" target="_blank" class="badge bg-success">Ouvrir</a>
							<?php else: ?> <span class="badge bg-danger">Aucun</a>  <?php endif; ?>
						</td>
					<?php endif; ?>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\formation\resources\views/planformation/index-search.blade.php ENDPATH**/ ?>