<meta name='csrf-token' content='<?php echo e(csrf_token()); ?>'>

<div class="modal-content">
	<div class="modal-header card-header"><h5 class="modal-title" id="varyingcontentModalLabel"><i class="<?php echo e($icone); ?>"></i>  <?php echo e($titre); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
		<div class="modal-body"><strong><div class="msgAction"></div></strong>
			<form id="formAction" class="needs-validation"  method="post" novalidate >
				<?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-6">
						<div class="mb-3">
							<label for="libelle_asspj" class="form-label"><?php echo trans('data.libelle_asspj'); ?> <strong style='color: red;'> *</strong></label>
							<?php echo Form::text('libelle_asspj','',["id"=>"libelle_asspj","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Libelle" ]); ?>

							<span class="text-danger" id="libelle_asspjError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="descr_asspj" class="form-label"><?php echo trans('data.descr_asspj'); ?> </label>
							<?php echo Form::text('descr_asspj','',["id"=>"descr_asspj","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Description" ]); ?>

							<span class="text-danger" id="descr_asspjError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="requis_file" class="form-label"><?php echo trans('data.requis_file'); ?> <strong style='color: red;'> *</strong></label>
							<?php $addrequis_file = array('' => 'Choisir', 'Oui' => 'Oui', 'Non' => 'Non');?>
							<?php echo Form::select('requis_file',$addrequis_file ,null,["id"=>"requis_file","class"=>"form-select allselect"]); ?>

							<span class="text-danger" id="requis_fileError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="type_piece" class="form-label"><?php echo trans('data.type_piece'); ?> <strong style='color: red;'> *</strong></label>
							<?php echo Form::select('type_piece',trans('entite.type_piece') ,session('type_pieceSess'),["id"=>"type_piece","class"=>"form-select allselect"]); ?>

							<span class="text-danger" id="type_pieceError"></span>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-outline-dark waves-effect waves-light" data-bs-dismiss="modal">Femer</button>
					<?php if(in_array('add_associerpiece',session('InfosAction'))): ?>
						<button id="valider" type="button"  class="btn btn-primary btn-label right btn-load" onclick="addAction();">
							<span class="d-flex align-items-center"><span class="flex-grow-1 me-2">Ajouter</span><span class="flex-shrink-0" role="status"></span></span>
							<i class="ri-add-line label-icon align-middle fs-16 ms-2"></i>
						</button>
					<?php endif; ?>
				</div>
			</form>
		</div>
	</div>

<script type="text/javascript"> $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}}); </script>

<script type="text/javascript">
	function addAction(){

		$('#valider').attr("disabled",!0);
		$('#valider .flex-shrink-0').addClass("spinner-border");
		$("div.msgAction").html('').hide(200);
		$('#libelle_asspjError').addClass('d-none');
		$('#descr_asspjError').addClass('d-none');
		$('#requis_fileError').addClass('d-none');
		$('#type_pieceError').addClass('d-none');
		var form = $('#formAction')[0];
		var data = new FormData(form);
		$.ajax({
			type: 'POST',url: '<?php echo e(url("/associerpiece/")); ?>',
			enctype:'multipart/form-data',data: data,processData: false,contentType: false,
			success: function(data) {
				$('#valider').attr("disabled",!1);
				$('#valider .flex-shrink-0').removeClass("spinner-border");
				if(data.response==1){
					$("div.msgAction").html('<div class="alert alert-success alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Infos </strong> Enregistrement r&eacute;ussi. </div>').show(200);
					window.location.reload();
				}else if(data.response==0){
					$("div.msgAction").html('<div class="alert alert-danger alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Echec de l\'enregistrement</strong> '+data.message+'</div>').show(200);
				}else{
					$.each(data.response, function(Key, value){
						var ErrorID = '#'+Key+'Error';
						$(ErrorID).removeClass('d-none');
						$(ErrorID).text(value);
					})
				}
			},error: function(data) {}
		});
	}
</script>

<?php /**PATH C:\wamp\www\formation\resources\views/associerpiece/create.blade.php ENDPATH**/ ?>