<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<?php if(count($list) != 0): ?>
	<table class="table table-striped table-bordered table-nowrap">
		<thead><tr>
			<th scope="col" ><?php echo trans('data.ref_pf'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.date_debu_pf').' - '.trans('data.date_fin_pf'); ?></th>
			<!-- <th scope="col" class="text-center"><?php echo trans('data.date_fin_pf'); ?></th> -->
			<th scope="col" class="text-center"><?php echo trans('data.date_sign_pf'); ?></th>
			<th scope="col"  class="text-center"><?php echo trans('data.etat_pf'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.entite_id'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.nbre_Agent'); ?></th>
			<th scope="col" class="text-center"><?php echo trans('data.nbre_Agent_inscr'); ?></th>
			<!-- <th scope="col" class="text-center"><?php echo trans('data.init_id'); ?></th> -->
		</tr></thead>
		<tbody>
			<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listgiwu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo $listgiwu->ref_pf; ?></td>
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_debu_pf)).' au '.date('d/m/Y',strtotime($listgiwu->date_fin_pf))); ?></td>
					<!-- <td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_fin_pf))); ?></td> -->
					<td class="text-center"><?php echo e(date('d/m/Y',strtotime($listgiwu->date_sign_pf))); ?></td>
					<td class="text-center"><?php if($listgiwu->etat_pf == 'a'): ?><span class="badge bg-success"><?php echo e(trans('entite.etat_plan')[$listgiwu->etat_pf]); ?></span> <?php else: ?> <span class="badge bg-danger"><?php echo e(trans('entite.etat_plan')[$listgiwu->etat_pf]); ?></span> <?php endif; ?></td>
					<td><?php echo isset($listgiwu->entite) ? $listgiwu->entite->sigle_entite : trans('data.not_found'); ?></td>
					<td class="text-center"><?php echo \App\Models\Planformation::NbreAgent($listgiwu->id_pf); ?></td>
					<td class="text-center"><?php echo \App\Models\Planformation::NbreAgentInscrit($listgiwu->id_pf); ?></td>
					<!-- <td><?php echo isset($listgiwu->users_g) ? $listgiwu->users_g->name." ".$listgiwu->users_g->prenom : trans('data.not_found'); ?></td> -->
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
	
	<?php echo $list->appends(['query'=>(isset($_GET['query'])?$_GET['query']:'') ])->links(); ?>

<?php else: ?>
	<div Class="alert alert-info"><strong>Info! </strong> <?php echo trans('data.AucunInfosTrouve'); ?> </div>
<?php endif; ?>
<?php /**PATH C:\wamp\www\formation\resources\views/cons/listPlanformation/index-search.blade.php ENDPATH**/ ?>