

<?php $__env->startSection('content'); ?>
<nav class="navbar navbar-expand-lg navbar-landing fixed-top" id="navbar">
            <div class="container">
                <a class="navbar-brand" href="index.html">
                    <img src="assets/images/logo-mtfpas.png" class="card-logo card-logo-dark" alt="logo dark" height="50">
                    <img src="assets/images/logo-mtfpas.png" class="card-logo card-logo-light" alt="logo light" height="50">
                </a>
                <button class="navbar-toggler py-0 fs-20 text-body" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="mdi mdi-menu"></i>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto mt-2 mt-lg-0" id="navbar-example">
                        <li class="nav-item">
                            <a class="nav-link active" href="<?php echo e(url('/')); ?>">Accueil</a>
                        </li>
                        <?php if(isset(session('InfosAgent')->nom_ag)): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/mypage')); ?>">Mon espace</a>
                            </li> 
                        <?php endif; ?>
                    </ul>
                    
                    <div class="">
                        <?php if(isset(session('InfosAgent')->nom_ag)): ?>
                            <a href="<?php echo e(url('logoutAgent')); ?>" class="btn btn-success">Déconnectez-vous</a>
                        <?php else: ?>
                            <a href="<?php echo e(url('/')); ?>" class="btn btn-success">Connectez-vous</a>
                            <!-- <a href="<?php echo e(url('registerUsager')); ?>" class="btn btn-success">S'inscrire</a> -->
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
        <!-- end navbar -->
        <div class="vertical-overlay" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent.show"></div>

        <?php echo $__env->make('site.entete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card overflow-hidden m-4">
    <div class="row justify-content-center g-0">
        <div class="col-lg-6">
            <div class="p-lg-5 p-4 auth-one-bg h-100">
                <div class="bg-overlay"></div>
                <div class="position-relative d-flex flex-column">
                    <div class="mb-4">
                        <a href="index.html" class="d-block">
                            <img src="assets/images/logo-light.png" alt="" height="18">
                        </a>
                    </div>
                    <div class="mt-auto">
                        <div class="mb-3">
                            <i class="ri-double-quotes-l display-4 text-success"></i>
                        </div>

                        <div id="qoutescarouselIndicators" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#qoutescarouselIndicators" data-bs-slide-to="0" class="active"
                                    aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#qoutescarouselIndicators" data-bs-slide-to="1"
                                    aria-label="Slide 2"></button>
                                <button type="button" data-bs-target="#qoutescarouselIndicators" data-bs-slide-to="2"
                                    aria-label="Slide 3"></button>
                            </div>
                            <div class="carousel-inner text-center text-white-50 pb-5">
                                <div class="carousel-item active">
                                    <p class="fs-15 fst-italic"><?php echo e(trans('data.infos1')); ?></p>
                                </div>
                                <div class="carousel-item">
                                    <p class="fs-15 fst-italic"><?php echo e(trans('data.infos2')); ?></p>
                                </div>
                                <div class="carousel-item">
                                    <p class="fs-15 fst-italic"><?php echo e(trans('data.infos3')); ?></p>
                                </div>
                            </div>
                        </div>
                        <!-- end carousel -->

                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="p-lg-5 p-4">
                <div>
                    <h5 class="text-primary">Créer un compte</h5>
                    <p class="text-muted">Création du compte sera possible si vous êtes dans un plan de formation.</p>
                </div>

                <div class="mt-4">
                    <!-- danger Alert -->
                    <?php if(session()->has('success') || session()->has('error')): ?>
                        <div class="col-md-12">
                            <div class="alert <?php echo e(session()->has('success') ? 'alert-success' : ''); ?> <?php echo e(session()->has('error') ? 'alert-danger' : ''); ?> alert-border-left alert-dismissible fade show" role="alert">
                                <i title ="<?php echo e(session()->has('errorMsg')? session()->get('errorMsg') : ''); ?>" class=" <?php echo e(session()->has('success') ? 'ri-notification-off-line' : 'ri-error-warning-line'); ?> me-3 align-middle"></i> <strong>Infos </strong> - <?php echo e(session()->has('success') ? session()->get('success') : session()->get('error')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(url('inscriagent')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="matricule" class="form-label"><?php echo e(trans('data.matricule')); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="matricule" name="matricule" placeholder="Entrer votre matricule" required>  
                        </div>
                        <div class="mb-3">
                            <label for="mail_ag" class="form-label"><?php echo e(trans('data.mail_ag')); ?> <span class="text-danger">*</span></label>
                            <input type="mail" class="form-control" id="mail_ag" name="mail_ag" placeholder="Entrer votre e-mail" required>  
                        </div>
                        <div class="mb-3">
                            <label for="tel_ag" class="form-label"><?php echo e(trans('data.tel_ag')); ?> <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="tel_ag" name="tel_ag" placeholder="Entrer votre téléphone" required>  
                        </div>
                        <div class="mb-2">
                            <label for="userpassword" class="form-label">Mot de passe  <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="userpassword" name="userpassword" placeholder="Enter password" required>
                        </div>
                        <div class="mb-2">
                            <label for="confiPassword" class="form-label">Confirmer <span class="text-danger">*</span></label>
                            <input type="password" class="form-control" id="confiPassword" name="confiPassword" placeholder="Confirmer password" required>
                        </div>
                        
                        <div class="mt-4">
                            <button class="btn btn-success w-100" type="submit">Créer votre compte</button>
                        </div>

                    </form>
                </div>

                <div class="mt-5 text-center">
                    <p class="mb-0">Vous avez déjà un compte ? <a href="<?php echo e(url('/')); ?>" class="fw-semibold text-primary text-decoration-underline">  S'authentifier</a> </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('site.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp\www\formation\resources\views/site/registreUsager.blade.php ENDPATH**/ ?>