<?php if($typeMenu == '-1'): ?>
	<!-- Code n'est plus utilisé -->

	<!-- <div class="modal-content">
		<div class="modal-body text-center p-4">
			<div class="mt-2">
				<h4 class="mb-3" style="color:#0ab39c" > Validation du dossier !</h4>
				<p class="text-muted mb-4"> Êtes-vous de vouloir valider ce dossier ? </p>
				<form action="<?php echo e(url('/dossier'.$typeMenu.'/validerData/'.$item->id_dossier)); ?>" method="POST">
						<?php echo csrf_field(); ?>
					<button type="button" class="btn btn-light" data-bs-dismiss="modal">Non</button>
					<button id="submit" class="btn btn-success">Oui</button>
				</form>
				<div class="hstack gap-2 justify-content-center"></div>
			</div>
		</div>
	</div> -->

<?php elseif($typeMenu == 'ms' || $typeMenu == 'pf' || $typeMenu == 'rs'): ?>

	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<div class="modal-content">
		<div class="modal-header card-header">
			<h5 class="modal-title" id="varyingcontentModalLabel">Validation du dossier : <?php echo e($item->agent->nom_ag.' '.$item->agent->prenom_ag); ?></h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">
			<strong><div class="msgAction"></div></strong>
			<form id="formAction" class="needs-validation" novalidate enctype='multipart/form-data'>
				<?php echo Form::hidden('id_dossier',$item->id_dossier,["class"=>"id_dossier"]); ?>

				<?php echo Form::hidden('typeMenu',$typeMenu,["id"=>"typeMenu"]); ?>

				<?php echo csrf_field(); ?>
				<div class="row">
					<!-- <div class="col-md-6">
						<div class="mb-3">
							<label for="ref_decision" class="form-label"><?php echo trans('data.ref_decision'); ?> <strong style='color: red;'> *</strong></label>
							<?php echo Form::text('ref_decision',$item->ref_decision,["id"=>"ref_decision","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Référence" ]); ?>

							<span class="text-danger" id="ref_decisionError"></span>
						</div>
					</div>
					<div class="col-md-6">
						<div class="mb-3">
							<label for="date_decision" class="form-label"><?php echo trans('data.date_decision'); ?> <strong style='color: red;'> *</strong></label>
							<?php echo Form::date('date_decision',$item->date_decision,["id"=>"date_decision","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer Date de décision" ]); ?>

							<span class="text-danger" id="date_decisionError"></span>
						</div>
					</div> -->
					<!-- <div class="col-md-12">
						<div class="mb-3">
							<label for="fichier_decision" class="form-label"><?php echo trans('data.fichier_decision').' '.$item->fichier_decision; ?> <strong style='color: red;'> *</strong></label>
							<input class="form-control" type="file" id="fichier_decision" name="fichier_decision" <?php echo isset($item->fichier_decision) ? '' : 'required'; ?>>
							<span class="text-danger" id="fichier_decisionError"></span>
						</div>
					</div> -->
					<div class="col-md-12">
						<div class="mb-3">
							<label for="etat_proces" class="form-label"><?php echo trans('data.etat_proces'); ?> <strong style='color: red;'> *</strong></label>
							<?php echo Form::select('etat_proces',trans('entite.decision_session') ,$item->etat_proces,["id"=>"etat_proces","class"=>"form-select allselect"]); ?>

							<span class="text-danger" id="etat_procesError"></span>
						</div>
					</div>
					<div class="col-md-12">
						<div class="mb-3">
							<label for="commentaire" class="form-label"><?php echo trans('data.commentaire'); ?></label>
							<?php echo Form::textarea('commentaire',$item->commentaire,["id"=>"commentaire","class"=>"form-control" ,'autocomplete'=>'off' ,'placeholder'=>"Entrer un commentaire" ,'rows'=>"3" ]); ?>

							<span class="text-danger" id="commentaireError"></span>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-light" data-bs-dismiss="modal">Femer</button>
					<button id="valider" type="button"  class="btn btn-success btn-load" onclick="addAction();"> 
						<span class="d-flex align-items-center"><span class="flex-grow-1 me-2">Valider</span><span class="flex-shrink-0" role="status"></span></span>
					</button>
				</div>
			</form>
		</div>
	</div>

	<script type="text/javascript"> $.ajaxSetup({headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')}}); </script>

	<script type="text/javascript">
		function addAction(){
			$('#valider').attr("disabled",!0);
			$('#valider .flex-shrink-0').addClass("spinner-border");
			$("div.msgAction").html('').hide(200);
			// $('#ref_decisionError').addClass('d-none');
			// $('#date_decisionError').addClass('d-none');
			// $('#fichier_decisionError').addClass('d-none');
			$('#etat_procesError').addClass('d-none');
			$('#commentaireError').addClass('d-none');
			var id_d = $('.id_dossier').val();
			var typeM = $("#typeMenu").val();
			let url_ = '<?php echo e(url("dossier:id/validerData")); ?>/'+id_d;
			url_ = url_.replace(':id',typeM);

			var form = $('#formAction')[0];
			var data = new FormData(form);
			$.ajax({
				type: 'POST',url: url_,
				enctype:'multipart/form-data',data: data,processData: false,contentType: false,
				success: function(data) {
					$('#valider').attr("disabled",!1);
					$('#valider .flex-shrink-0').removeClass("spinner-border");
					if(data.response!=1){
						$.each(data.response, function(Key, value){var ErrorID = '#'+Key+'Error';$(ErrorID).removeClass('d-none');$(ErrorID).text(value);})
					}else{
						$("div.msgAction").html('<div class="alert alert-success alert-border-left alert-dismissible fade show" role="alert"><i class="ri-notification-off-line me-3 align-middle"></i> <strong>Infos </strong> Décision prise et envoyée avec succès </div>').show(200);
						window.location.reload();
					}
				},
				error: function(data) {}
			});
		}

	</script>


<?php endif; ?>
<?php /**PATH C:\wamp\www\formation\resources\views/dossier/valider.blade.php ENDPATH**/ ?>